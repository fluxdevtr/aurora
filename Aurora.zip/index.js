require('dotenv').config();
const { Client, GatewayIntentBits, Collection, REST, Routes, EmbedBuilder, ActivityType, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionFlagsBits, RoleSelectMenuBuilder, ChannelSelectMenuBuilder, MessageFlags, Events } = require('discord.js');
const fs = require('fs');
const path = require('path');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildVoiceStates
    ]
});

client.commands = new Collection();
client.voiceData = new Map();
client.tempConfigs = new Map();
client.voiceConfig = { ad: 'Aurora Bot System' };

const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir);
const ticketDataPath = path.join(dataDir, 'tickets.json');
if (!fs.existsSync(ticketDataPath)) fs.writeFileSync(ticketDataPath, JSON.stringify({}));

const commandsData = [];
const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

const BOT_DURUMU = '#EğitimdeŞiddeteHayır | /yardım';

for (const file of commandFiles) {
    const filePath = path.join(commandsPath, file);
    const command = require(filePath);
    if ('data' in command && 'execute' in command) {
        client.commands.set(command.data.name, command);
        commandsData.push(command.data.toJSON());
    }
}

client.once(Events.ClientReady, async () => {
    client.user.setActivity(BOT_DURUMU, { type: ActivityType.Playing });
    const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);
    try {
        await rest.put(
            Routes.applicationCommands(process.env.CLIENT_ID),
            { body: commandsData },
        );
        console.log(`Bot başlatıldı: ${client.user.tag}`);
    } catch (error) {
        console.error(error);
    }
});

client.on(Events.InteractionCreate, async interaction => {
    if (interaction.isChatInputCommand()) {
        const command = client.commands.get(interaction.commandName);
        if (!command) return;
        try {
            await command.execute(interaction);
        } catch (error) {
            console.error(error);
            const msg = { content: 'Komut işlenirken hata oluştu.', flags: [MessageFlags.Ephemeral] };
            interaction.replied || interaction.deferred ? await interaction.followUp(msg) : await interaction.reply(msg);
        }
    }

    if (interaction.isRoleSelectMenu() && interaction.customId === 'ticket_role_select') {
        client.tempConfigs.set(interaction.user.id, interaction.values);
        
        const embed = new EmbedBuilder()
            .setColor(0x5865F2)
            .setTitle('Kanal Seçimi')
            .setDescription('Destek mesajının gönderileceği kanalı seçin.');
        
        const row = new ActionRowBuilder()
            .addComponents(
                new ChannelSelectMenuBuilder()
                    .setCustomId('ticket_channel_select')
                    .setPlaceholder('Kanal seçin...')
                    .setChannelTypes(ChannelType.GuildText)
            );
        
        await interaction.update({ embeds: [embed], components: [row] });
    }

    if (interaction.isChannelSelectMenu() && interaction.customId === 'ticket_channel_select') {
        const roleIds = client.tempConfigs.get(interaction.user.id);
        if (!roleIds) return interaction.reply({ content: 'Oturum zaman aşımına uğradı, lütfen tekrar deneyin.', flags: [MessageFlags.Ephemeral] });

        const channelId = interaction.values[0];
        const channel = interaction.guild.channels.cache.get(channelId);

        const tickets = JSON.parse(fs.readFileSync(ticketDataPath, 'utf-8'));
        tickets[interaction.guild.id] = { roleIds, channelId };
        fs.writeFileSync(ticketDataPath, JSON.stringify(tickets, null, 2));

        const panelEmbed = new EmbedBuilder()
            .setColor(0x5865F2)
            .setTitle('Destek Talebi')
            .setDescription('Yardım almak için aşağıdaki butona tıklayarak talep oluşturabilirsiniz.')
            .setFooter({ text: client.voiceConfig.ad });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('create_ticket')
                    .setLabel('Talep Oluştur')
                    .setEmoji('📩')
                    .setStyle(ButtonStyle.Primary)
            );

        await channel.send({ embeds: [panelEmbed], components: [row] });
        client.tempConfigs.delete(interaction.user.id);
        await interaction.update({ content: 'Sistem başarıyla kuruldu.', embeds: [], components: [] });
    }

    if (interaction.isButton() && interaction.customId === 'create_ticket') {
        await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });

        const tickets = JSON.parse(fs.readFileSync(ticketDataPath, 'utf-8'));
        const config = tickets[interaction.guild.id];
        if (!config) return interaction.editReply({ content: 'Sistem ayarları bulunamadı.' });

        let category = interaction.guild.channels.cache.find(c => c.name === 'Destek Talepleri' && c.type === ChannelType.GuildCategory);
        if (!category) {
            category = await interaction.guild.channels.create({
                name: 'Destek Talepleri',
                type: ChannelType.GuildCategory
            });
        }

        const permissionOverwrites = [
            { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
            { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] }
        ];

        config.roleIds.forEach(roleId => {
            const role = interaction.guild.roles.cache.get(roleId);
            if (role) {
                permissionOverwrites.push({ id: roleId, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] });
            }
        });

        const channel = await interaction.guild.channels.create({
            name: `talep-${interaction.user.username}`,
            type: ChannelType.GuildText,
            parent: category.id,
            permissionOverwrites: permissionOverwrites
        });

        const welcomeEmbed = new EmbedBuilder()
            .setColor(0x5865F2)
            .setTitle('Talep Oluşturuldu')
            .setDescription(`Merhaba ${interaction.user}, yetkililer en kısa sürede sizinle ilgilenecektir.\nTalebi kapatmak için kilidi kullanabilirsiniz.`)
            .setFooter({ text: client.voiceConfig.ad });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('close_ticket')
                    .setLabel('Talebi Kapat')
                    .setEmoji('🔒')
                    .setStyle(ButtonStyle.Danger)
            );

        const mentionText = config.roleIds.map(id => `<@&${id}>`).join(' ');
        await channel.send({ content: mentionText, embeds: [welcomeEmbed], components: [row] });
        await interaction.editReply({ content: `Talebiniz oluşturuldu: ${channel}` });
    }

    if (interaction.isButton() && interaction.customId === 'close_ticket') {
        await interaction.reply('Talep kapatılıyor...');
        setTimeout(() => interaction.channel.delete().catch(() => {}), 5000);
    }
});

client.on(Events.VoiceStateUpdate, async (oldState, newState) => {
    if (oldState.member.user.bot) return;
    if (!oldState.channelId && newState.channelId) {
        client.voiceData.set(newState.member.id, Date.now());
    }
    if (oldState.channelId && !newState.channelId) {
        const joinTime = client.voiceData.get(oldState.member.id);
        if (!joinTime) return;
        const durationMs = Date.now() - joinTime;
        client.voiceData.delete(oldState.member.id);
        const minutes = Math.floor(durationMs / 60000);
        const seconds = Math.floor((durationMs % 60000) / 1000);
        const embed = new EmbedBuilder()
            .setColor(0x0099FF)
            .setTitle('Ses Kanalı İstatistiği')
            .setDescription(`**${oldState.guild.name}** sunucusundaki ses kanalından ayrıldın.\nGeçirdiğin süre: **${minutes} dakika ${seconds} saniye**`)
            .setFooter({ text: client.voiceConfig.ad });
        oldState.member.send({ embeds: [embed] }).catch(() => {});
    }
});

client.login(process.env.TOKEN);