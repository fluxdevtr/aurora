const { SlashCommandBuilder, ActivityType } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('durum-degistir')
        .setDescription('Botun oynuyor durumunu değiştirir.')
        .addStringOption(option =>
            option.setName('yeni_durum')
                .setDescription('Botun yeni durumu')
                .setRequired(true)),
    async execute(interaction) {
        await interaction.client.application.fetch();
        const appOwner = interaction.client.application.owner;
        
        let hasPermission = false;
        if (appOwner.members) {
            hasPermission = appOwner.members.has(interaction.user.id);
        } else {
            hasPermission = appOwner.id === interaction.user.id;
        }

        if (!hasPermission) {
            return interaction.reply({ content: 'Bu komutu yalnızca botun geliştiricisi kullanabilir.', ephemeral: true });
        }

        const yeniDurum = interaction.options.getString('yeni_durum');
        interaction.client.user.setActivity(yeniDurum, { type: ActivityType.Playing });

        await interaction.reply({ content: `Bot durumu başarıyla güncellendi: **${yeniDurum}**`, ephemeral: true });
    },
};