const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('kick')
        .setDescription('Belirtilen kullanıcıyı sunucudan atar.')
        .addUserOption(option =>
            option.setName('kullanici')
                .setDescription('Atılacak kullanıcı')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('sebep')
                .setDescription('Atılma sebebi'))
        .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),
    async execute(interaction) {
        const target = interaction.options.getMember('kullanici');
        const reason = interaction.options.getString('sebep') ?? 'Sebep belirtilmedi.';
        if (!target) return interaction.reply({ content: 'Kullanıcı bulunamadı.', ephemeral: true });
        await target.kick(reason);
        await interaction.reply({ content: `${target.user.tag} sunucudan atıldı. Sebep: ${reason}` });
    },
};