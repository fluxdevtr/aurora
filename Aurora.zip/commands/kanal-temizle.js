const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('kanal-temizle')
        .setDescription('Kanalı silip tüm ayarları ve izinleriyle yeniden oluşturur.')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
    async execute(interaction) {
        const channel = interaction.channel;
        const position = channel.position;

        const newChannel = await channel.clone();
        await newChannel.setPosition(position);
        await channel.delete();

        await newChannel.send({ content: `${interaction.user} tarafından bu kanal temizlendi.` });
    },
};