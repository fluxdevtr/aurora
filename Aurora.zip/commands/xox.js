const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('xox')
        .setDescription('XOX oyunu oynarsınız.')
        .addUserOption(option =>
            option.setName('rakip')
                .setDescription('Oynamak istediğiniz rakip')
                .setRequired(true)),
    async execute(interaction) {
        const opponent = interaction.options.getUser('rakip');
        if (opponent.bot) return interaction.reply({ content: 'Botlarla oynayamazsın.', ephemeral: true });
        if (opponent.id === interaction.user.id) return interaction.reply({ content: 'Kendinle oynayamazsın.', ephemeral: true });

        let board = Array(9).fill(null);
        let currentPlayer = interaction.user;
        
        const checkWin = () => {
            const lines = [
                [0, 1, 2], [3, 4, 5], [6, 7, 8],
                [0, 3, 6], [1, 4, 7], [2, 5, 8],
                [0, 4, 8], [2, 4, 6]
            ];
            for (let i = 0; i < lines.length; i++) {
                const [a, b, c] = lines[i];
                if (board[a] && board[a] === board[b] && board[a] === board[c]) return board[a];
            }
            if (!board.includes(null)) return 'tie';
            return null;
        };

        const getRows = () => {
            const rows = [];
            for (let i = 0; i < 3; i++) {
                const row = new ActionRowBuilder();
                for (let j = 0; j < 3; j++) {
                    const index = i * 3 + j;
                    const btn = new ButtonBuilder()
                        .setCustomId(`xox_${index}`)
                        .setStyle(board[index] === 'X' ? ButtonStyle.Primary : (board[index] === 'O' ? ButtonStyle.Danger : ButtonStyle.Secondary))
                        .setLabel(board[index] ? board[index] : '\u200b')
                        .setDisabled(board[index] !== null);
                    row.addComponents(btn);
                }
                rows.push(row);
            }
            return rows;
        };

        const message = await interaction.reply({
            content: `Sıra: <@${currentPlayer.id}>`,
            components: getRows(),
            fetchReply: true
        });

        const collector = message.createMessageComponentCollector({ componentType: ComponentType.Button, time: 60000 });

        collector.on('collect', async i => {
            if (i.user.id !== currentPlayer.id) {
                return i.reply({ content: 'Sıra sende değil!', ephemeral: true });
            }
            const index = parseInt(i.customId.split('_')[1]);
            board[index] = currentPlayer.id === interaction.user.id ? 'X' : 'O';
            
            const winner = checkWin();
            if (winner) {
                collector.stop(winner);
                const endContent = winner === 'tie' ? 'Oyun berabere bitti!' : `<@${currentPlayer.id}> kazandı!`;
                await i.update({ content: endContent, components: getRows() });
                return;
            }

            currentPlayer = currentPlayer.id === interaction.user.id ? opponent : interaction.user;
            await i.update({ content: `Sıra: <@${currentPlayer.id}>`, components: getRows() });
            collector.resetTimer();
        });

        collector.on('end', (collected, reason) => {
            if (reason === 'time') {
                interaction.editReply({ content: 'Süre doldu, oyun iptal edildi.', components: [] }).catch(() => {});
            }
        });
    },
};