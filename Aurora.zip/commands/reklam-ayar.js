const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('reklam-ayar')
        .setDescription('DM üzerinden gönderilen ses istatistiği reklam metnini ayarlar.')
        .addStringOption(option =>
            option.setName('metin')
                .setDescription('Alt kısımda görünecek reklam metni')
                .setRequired(true)),
    async execute(interaction) {
        await interaction.client.application.fetch();
        const appOwner = interaction.client.application.owner;
        
        let hasPermission = false;
        if (appOwner.members) {
            hasPermission = appOwner.members.has(interaction.user.id);
        } else {
            hasPermission = appOwner.id === interaction.user.id;
        }

        if (!hasPermission) {
            return interaction.reply({ content: 'Bu komutu yalnızca botun geliştiricisi/sahibi kullanabilir.', ephemeral: true });
        }

        const yeniMetin = interaction.options.getString('metin');
        interaction.client.voiceConfig.ad = yeniMetin;

        await interaction.reply({ content: `Reklam metni başarıyla güncellendi: **${yeniMetin}**`, ephemeral: true });
    },
};