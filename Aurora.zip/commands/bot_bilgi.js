const { SlashCommandBuilder, EmbedBuilder, version } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('bot-bilgi')
        .setDescription('Botun istatistiklerini ve teknik detaylarını listeler.'),
    async execute(interaction) {
        const totalUptime = process.uptime();
        const days = Math.floor(totalUptime / 86400);
        const hours = Math.floor(totalUptime / 3600) % 24;
        const minutes = Math.floor(totalUptime / 60) % 60;
        const seconds = Math.floor(totalUptime % 60);
        
        const embed = new EmbedBuilder()
            .setColor(0x0099FF)
            .setAuthor({ name: interaction.client.user.username, iconURL: interaction.client.user.displayAvatarURL() })
            .setDescription('Aurora botunun güncel istatistikleri ve teknik altyapı bilgileri.')
            .addFields(
                { name: 'Gecikme (Ping)', value: `${interaction.client.ws.ping}ms`, inline: true },
                { name: 'Çalışma Süresi', value: `${days}g ${hours}sa ${minutes}dk ${seconds}sn`, inline: true },
                { name: 'Sunucular', value: `${interaction.client.guilds.cache.size}`, inline: true },
                { name: 'Kullanıcılar', value: `${interaction.client.guilds.cache.reduce((acc, guild) => acc + guild.memberCount, 0)}`, inline: true },
                { name: 'Discord.js Sürümü', value: `v${version}`, inline: true },
                { name: 'Node.js Sürümü', value: process.version, inline: true },
                { name: 'Bellek Kullanımı', value: `${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB`, inline: true }
            )
            .setTimestamp()
            .setFooter({ text: interaction.user.tag, iconURL: interaction.user.displayAvatarURL() });

        await interaction.reply({ embeds: [embed] });
    },
};