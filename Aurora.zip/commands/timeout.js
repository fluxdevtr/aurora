const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('timeout')
        .setDescription('Belirtilen kullanıcıyı susturur.')
        .addUserOption(option =>
            option.setName('kullanici')
                .setDescription('Susturulacak kullanıcı')
                .setRequired(true))
        .addIntegerOption(option =>
            option.setName('sure')
                .setDescription('Süre (dakika cinsinden)')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('sebep')
                .setDescription('Susturulma sebebi'))
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
    async execute(interaction) {
        const target = interaction.options.getMember('kullanici');
        const duration = interaction.options.getInteger('sure') * 60 * 1000;
        const reason = interaction.options.getString('sebep') ?? 'Sebep belirtilmedi.';
        if (!target) return interaction.reply({ content: 'Kullanıcı bulunamadı.', ephemeral: true });
        await target.timeout(duration, reason);
        await interaction.reply({ content: `${target.user.tag} ${interaction.options.getInteger('sure')} dakika susturuldu. Sebep: ${reason}` });
    },
};