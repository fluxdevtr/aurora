const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ping')
        .setDescription('Botun gecikme süresini gösterir.'),
    async execute(interaction) {
        const sent = await interaction.reply({ content: 'Ölçülüyor...', fetchReply: true });
        const latency = sent.createdTimestamp - interaction.createdTimestamp;
        await interaction.editReply(`Websocket: ${interaction.client.ws.ping}ms\nAPI: ${latency}ms`);
    },
};