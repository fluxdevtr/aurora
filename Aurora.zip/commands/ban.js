const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ban')
        .setDescription('Belirtilen kullanıcıyı sunucudan yasaklar.')
        .addUserOption(option =>
            option.setName('kullanici')
                .setDescription('Yasaklanacak kullanıcı')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('sebep')
                .setDescription('Yasaklanma sebebi'))
        .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
    async execute(interaction) {
        const target = interaction.options.getUser('kullanici');
        const reason = interaction.options.getString('sebep') ?? 'Sebep belirtilmedi.';
        await interaction.guild.members.ban(target, { reason });
        await interaction.reply({ content: `${target.tag} sunucudan yasaklandı. Sebep: ${reason}` });
    },
};