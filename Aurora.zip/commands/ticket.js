const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, ActionRowBuilder, RoleSelectMenuBuilder, ChannelSelectMenuBuilder, ButtonBuilder, ButtonStyle, ChannelType } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ticket-kur')
        .setDescription('Destek talebi sistemini kurar.')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    async execute(interaction) {
        const embed = new EmbedBuilder()
            .setColor(0x5865F2)
            .setTitle('Destek Sistemi Kurulumu')
            .setDescription('Lütfen destek taleplerine bakacak yetkili rollerini seçin. Birden fazla rol seçebilirsiniz.');

        const row = new ActionRowBuilder()
            .addComponents(
                new RoleSelectMenuBuilder()
                    .setCustomId('ticket_role_select')
                    .setPlaceholder('Yetkili rollerini seçin...')
                    .setMinValues(1)
                    .setMaxValues(10)
            );

        await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
    }
};