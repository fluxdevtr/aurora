const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('yardım')
        .setDescription('Tüm komutları listeler.'),
    async execute(interaction) {
        const commandList = interaction.client.commands.map(cmd => `**/${cmd.data.name}** - ${cmd.data.description}`).join('\n');

        const embed = new EmbedBuilder()
            .setColor(0x0099FF)
            .setTitle('Aurora - Yardım Menüsü')
            .setDescription(`Aşağıda kullanabileceğiniz tüm komutlar bulunmaktadır.\n\n${commandList}`)
            .setTimestamp()
            .setFooter({ text: 'Aurora Bot', iconURL: interaction.client.user.displayAvatarURL() });
            
        await interaction.reply({ embeds: [embed] });
    },
};