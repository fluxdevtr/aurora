const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('adam-asmaca')
        .setDescription('Adam asmaca oyunu oynarsınız.'),
    async execute(interaction) {
        const words = ['discord', 'yazilim', 'gelistirici', 'sunucu', 'bot', 'moderator', 'kapsam', 'degisken', 'aurora'];
        const word = words[Math.floor(Math.random() * words.length)];
        let guessed = [];
        let mistakes = 0;
        const maxMistakes = 6;

        const getDisplayWord = () => word.split('').map(char => guessed.includes(char) ? char : '\\_').join(' ');

        await interaction.reply({ content: `Adam Asmaca başladı! 6 hata hakkınız var.\nKelime: ${getDisplayWord()}` });

        const filter = m => m.author.id === interaction.user.id && m.content.length === 1 && /[a-z]/i.test(m.content);
        const collector = interaction.channel.createMessageCollector({ filter, time: 60000 });

        collector.on('collect', async m => {
            const letter = m.content.toLowerCase();
            if (guessed.includes(letter)) {
                await interaction.followUp({ content: 'Bu harfi zaten denedin.', ephemeral: true });
                m.delete().catch(() => {});
                return;
            }
            guessed.push(letter);
            m.delete().catch(() => {});

            if (!word.includes(letter)) {
                mistakes++;
            }

            const currentDisplay = getDisplayWord();
            
            if (!currentDisplay.includes('\\_')) {
                collector.stop('win');
                await interaction.editReply({ content: `Tebrikler, kazandınız! Kelime: **${word}**` });
            } else if (mistakes >= maxMistakes) {
                collector.stop('lose');
                await interaction.editReply({ content: `Kaybettiniz! Kelime: **${word}**` });
            } else {
                await interaction.editReply({ content: `Hata: ${mistakes}/${maxMistakes}\nKelime: ${currentDisplay}` });
                collector.resetTimer();
            }
        });

        collector.on('end', (collected, reason) => {
            if (reason === 'time') {
                interaction.editReply({ content: `Süre doldu! Kelime: **${word}**` }).catch(() => {});
            }
        });
    },
};